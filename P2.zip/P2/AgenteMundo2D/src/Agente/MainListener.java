package Agente;

/**
 * @author Diego Velázquez Ortuño
 */
public interface MainListener {
    // Este es un listener que se encuentra en el main
    void onIniciarButtonPreseed();
}
