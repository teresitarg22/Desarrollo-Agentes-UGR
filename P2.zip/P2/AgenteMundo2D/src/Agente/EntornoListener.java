package Agente;

/**
 * @author Diego Velázquez Ortuño
 */
public interface EntornoListener {
    void onPosicionAgenteActualizada(PosiblesMovimientos movimiento);
}
